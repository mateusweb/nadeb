QUICK INSTALL

You need to have a Webserver with PHP support running

1. create a directory under your server web root and unzip files there
2. publish the swf there
3. create a "files" folder under your previous folder with write permissons (the PHP script attemps to create if it doesn't exists, but should have write permissons over the folder)
4. Check your example trough a browser (not from inside Flash) and webserver (i.e http://localhost/upload/upload.html)

Post your questions on http://www.flash-db.com/Board/